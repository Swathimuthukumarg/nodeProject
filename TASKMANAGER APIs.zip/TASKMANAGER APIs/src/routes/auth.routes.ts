import { Router } from 'express';
import { mobileLogin } from '../controllers/auth.controller';

const router = Router();
router.post('/mobile-login', mobileLogin);

export default router;
