import { Request, Response } from 'express';
import { AppDataSource } from '../config/data-source';
import { User } from '../entities/User';
import { generateToken } from '../utils/jwt';

const userRepo = AppDataSource.getRepository(User);

export const mobileLogin = async (req: Request, res: Response) => {
  const { mobile, name } = req.body;

  if (!mobile) return res.status(400).json({ message: 'Mobile number is required' });

  let user = await userRepo.findOne({ where: { mobile } });

  if (!user) {
    if (!name) return res.status(400).json({ message: 'Name is required for new users' });
    user = userRepo.create({ name, mobile });
    await userRepo.save(user);
  }

  const token = generateToken(user.id);
  res.status(200).json({ user, token });
};
