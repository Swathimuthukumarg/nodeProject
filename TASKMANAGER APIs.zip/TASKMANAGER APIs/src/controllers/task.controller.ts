import { Request, Response } from 'express';
import { AppDataSource } from '../config/data-source';
import { Task } from '../entities/Task';
import { User } from '../entities/User';

const taskRepo = AppDataSource.getRepository(Task);
const userRepo = AppDataSource.getRepository(User);

export const createTask = async (req: Request, res: Response) => {
  const { title, description } = req.body;
  const user = await userRepo.findOneBy({ id: req.user.id });
  if (!user) return res.status(404).json({ message: 'User not found' });

  const task = taskRepo.create({ title, description, user });
  await taskRepo.save(task);
  res.status(201).json(task);
};

export const getTasks = async (req: Request, res: Response) => {
  const tasks = await taskRepo.find({ where: { user: { id: req.user.id } } });
  res.json(tasks);
};

export const updateTask = async (req: Request, res: Response) => {
  const { id } = req.params;
  const updates = req.body;
  const task = await taskRepo.findOneBy({ id: Number(id) });
  if (!task) return res.status(404).json({ message: 'Task not found' });

  Object.assign(task, updates);
  await taskRepo.save(task);
  res.json(task);
};
