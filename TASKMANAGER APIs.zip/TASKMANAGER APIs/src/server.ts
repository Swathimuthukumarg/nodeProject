import 'reflect-metadata';
import express from 'express';
import dotenv from 'dotenv';
import { AppDataSource } from './config/data-source';
import authRoutes from './routes/auth.routes';
import taskRoutes from './routes/task.routes';

dotenv.config();

const app = express();
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);

AppDataSource.initialize()
  .then(() => {
    console.log('✅ Data Source has been initialized');
    app.listen(5000, () => console.log('🚀 Server is running on port 5000'));
  })
  .catch((err) => {
    console.error('❌ Error during Data Source initialization:', err);
  });
